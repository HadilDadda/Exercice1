SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `medcin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `medcin` (`id`, `username`, `password`) VALUES
(1, 'hadil', 'dadda'),
(3, 'oussama', 'ouqail'),
(4, 'younes', 'abou'),
(5, 'hiba', 'elmers'),
(6, 'delwende', 'donald');

ALTER TABLE `medcin`
  ADD PRIMARY KEY (`id`);

  ALTER TABLE `medcin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;