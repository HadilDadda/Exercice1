<?php

namespace App\rendezvous;

class Month{
/**
*@param int le mois compris entre 1 et 12
*@param int $year
*/
public function __construct(int $Month,int $year)
{
 if($month < 1 || $month > 12)
 {throw new Exception(message "le mois $month  n'est pas valide"); }
 if($year < 2020)
 {
     throw new Exception(message"l'annee est inferieur a 2020 ");

 }

}



?>