<head>
		<meta charset="utf-8">
		<title></title>
		
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" 
	 integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	 <style>
		 body{
			 background-image:url("rendezvous.jpg");
			 background-size:1859px 940px;
		 }
		 </style>
	</head>
	<body>
<form method="POST" >
		<h1 align="center">
			LES RENDEZ-VOUS DES PATIENTS
		</h1>
		<br/><br/>
		<br/>
		<table  align="center" width="400px" height="200px" border="0">
			<tr>
				<td>La Date Du Rendez-Vous:</td>
				<td><input  type="date" name="datte" style="width:200px"  /></td>
           </tr>
		   <tr>
			   <td>Lieu Du Rendez-Vous: </td>
			   <td><input type="time" name="heure" style="width:200px"/></td>
           </tr>
		   <tr>
			   <td>Departement De l'Hopital</td>
			   <td><input type="text" name="departement" style="width:200px" /></td>
		   </tr>
		   <tr>
		   <td align="center" colspan="2" />
		   <input type="submit" name="sauvgarder" value="Sauvgarder" style="width:200px"/>
		</tr>



		</table>
		</form>
	</body>
</html>

<?php



$servername="localhost";
$username="root";
$dbname="hopital";
$password="";
$con=new mysqli($servername,$username,$password,$dbname);
if ($con->connect_error)
{
die ("connexion failed:".$con->connect_error);
}

if(isset($_POST["sauvgarder"]))
{

	$consultation=$_POST["datte"];

	$lieux=$_POST["heure"];
	
	$raison=$_POST["departement"];
	//echo $fievre ;
	$sql_i="INSERT INTO rendez_vous(departement,datte,heure)VALUES('".$raison."','".$consultation."','".$lieux."')";
	if (mysqli_query($con,$sql_i)){
	echo"insertion reussie";
	}
	else{
	echo"Erreur :".$sql_i."<br>".mysqli_error($con);
	
	}



}







?>


