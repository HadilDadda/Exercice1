create table calendar
(DateKey int not NOT NULL,
[DATE] DATE NOT NULL,
 [Day] TINYINT NOT NULL,
 DayOFWEEK TINYINT NOT NULL,
 DayName VARCHAR(10) NOT NULL,

)

SELECT 
CAST (D.Datekey AS INT) AS Datekey,
D.[DATE] AS [DATE]
CAST(D.[day] AS TINYINT)AS [day],
CAST(d.[dayofweek] AS TINYINT) AS [dayOFWEEK],
CAST(DATENAME (WEEKDAY.D.[DATE]) AS VARCHAR(10)) [day] AS [dayNAME],