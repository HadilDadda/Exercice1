<?php

$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="hopital";
//definir la variable de connexion a la bdd
$con=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname); session_start();
//if(isset($_POST['Login'])){
    
       //pour recuperer
       //$_SESSION['username']=$_POST['username'];
       $_SESSION['user']=$_POST['username'];

       //pour afficher
       
       
      // echo "bonjour".$_SESSION['username'];
//}


  if($_SERVER['REQUEST_METHOD'] == "POST")
  {
    $user_name = $_POST['username'];
    $password = $_POST['password'];
    
    if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
    {
      $query = "select * from medcin where username = '$user_name' limit 1";//selectionner de la table ou le champ
      $result = mysqli_query($con, $query);
      if($result)
      {
        if($result && mysqli_num_rows($result) > 0)
        {
          $user_data = mysqli_fetch_assoc($result);
          if($user_data['password'] === $password)
          {
            $_SESSION['id'] = $user_data['id'];
              header("Location:profileMedcin.php");
          }
        }
      }
          echo"<script type='text/javascript'>alert('Votre login et/ou password sont incorrectes !');</script>";
    }else
    {
      echo"<script type='text/javascript'>alert('Votre login et/ou password sont incorrectes !');</script>";
    }
  }




 

?>