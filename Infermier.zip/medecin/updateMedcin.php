<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link href="styleModification.css" rel="stylesheet" type="text/css">
</head>
<style>
#bob{
	
}
.auto-style1 {
	margin-top: 0px;
}
</style>
<body style="background-image: url(enquete-medecins.png);" > 
<form   method="post" >

            <table align="center">
             <tr>  
                <td style="height: 123px"> Entrez votre ancien UserName <input type="text"name="user" required="required"> </td>                         
                <tr> <td style="height: 125px"> Nouveau UserName    <input type="text" name="userN" required="required"> </td><br></tr>
                <tr> <td style="height: 123px"> Entrez votre ancien Password <input type="password" name="mot2pas" required="required"> </td></tr><br>
                <tr> <td style="height: 121px"> Nouveau Password <input type="password" name="mot2pasN" required="required"> </td></tr><br> 
                <tr> <td> <a href="gmd.php"> <button type="submit">Modifier</button></a>
                 <a href="profileMedcin.php"><button type="button" >Annuler</button></a></td><br>
            </tr>
                 
 </table>           
 </form>
 <?php 
 if(isset($_POST['user'])||isset($_POST['userN'])||isset($_POST['mot2pas'])||isset($_POST['mot2pasN']))
 {
// Definition des infos de connection
$user = 'root';   // le nom de l'utilisateur
$pass = '';       // le mot de passe 
$host = 'localhost';  // le serveur de base de données
$bdd = 'hopital';  // le nom de la base de données 

// 1eme  etape 
// connection au serveur de la base de donnees
$link = mysqli_connect($host, $user, $pass, $bdd) or die("Erreur de connexion au serveur");

// 3eme etape  : 
// Selectionner la BDD
mysqli_select_db($link, $bdd) or die("Erreur de connexion a la BDD");

//Exécuter le UPDATE dans la table
$update = "UPDATE medcin  SET username='$_POST[userN]',password='$_POST[mot2pasN]' WHERE username='$_POST[user]' and password='$_POST[mot2pas]' ";


$rep = mysqli_query($link,$update) or die("Erreur de modification des donnèes");

// Deconnexion de la BDD
mysqli_close($link);
 }
?>
       

</body>
</html>