-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 23 oct. 2021 à 07:28
-- Version du serveur :  10.4.18-MariaDB
-- Version de PHP : 8.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `hopital`
--

-- --------------------------------------------------------

--
-- Structure de la table `ajoute_patient`
--

CREATE TABLE `ajoute_patient` (
  `heure` time NOT NULL,
  `data` date NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `numero` varchar(17) NOT NULL,
  `adress` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `lieu` varchar(50) NOT NULL,
  `numeroAss` int(15) NOT NULL,
  `expiration` int(10) NOT NULL,
  `fievre` varchar(4) NOT NULL,
  `Allergie` varchar(4) NOT NULL,
  `sexe` varchar(3) NOT NULL,
  `raison` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `ajoute_patient`
--

INSERT INTO `ajoute_patient` (`heure`, `data`, `nom`, `prenom`, `numero`, `adress`, `date`, `lieu`, `numeroAss`, `expiration`, `fievre`, `Allergie`, `sexe`, `raison`) VALUES
('12:00:00', '2021-09-29', 'el mers', 'hiba', '(514)298-8501', '3366rue allard,montreal,quebec', '2021-02-09', 'casablanca', 99887, 12, '0', '', '', ''),
('18:07:00', '2021-09-30', 'uhj', 'h', '(514)298-8501', '3366rue allard,montreal,quebec', '2021-10-06', 'casablanca', 99887, 12, 'NON', '', '', ''),
('00:00:00', '0000-00-00', 'uhj', 'h', '(514)298-8501', '3366rue allard,montreal,quebec', '2021-10-07', 'casablanca', 99887, 12, 'OUI', '', '', ''),
('18:15:00', '2021-08-17', 'youssef', 'abouziad', '(438)897-3098', '1167 rue berrie , montreal, quebec', '1998-11-19', 'montral', 98871, 18, 'OUI', 'OUI', '', ''),
('19:20:00', '2021-11-03', 'youssef', 'abouziad', '(438)897-3098', '1167 rue berrie , montreal, quebec', '1989-02-16', 'montral', 98871, 18, 'OUI', 'OUI', '', ''),
('08:08:00', '2021-10-26', 'hh', 'huh', '(438)897-3098', '1167 rue berrie , montreal, quebec', '2021-10-06', 'montral', 98871, 18, 'OUI', 'OUI', 'hom', ''),
('08:08:00', '2021-10-26', 'hh', 'huh', '(438)897-3098', '1167 rue berrie , montreal, quebec', '2021-10-06', 'montral', 98871, 18, 'OUI', 'OUI', 'hom', ''),
('08:08:00', '2021-10-26', 'hh', 'huh', '(438)897-3098', '1167 rue berrie , montreal, quebec', '2021-10-06', 'montral', 98871, 18, 'OUI', 'OUI', 'hom', ''),
('08:08:00', '2021-10-26', 'hh', 'huh', '(438)897-3098', '1167 rue berrie , montreal, quebec', '2021-10-06', 'montral', 98871, 18, 'OUI', 'OUI', 'hom', ''),
('08:08:00', '2021-10-26', 'hh', 'huh', '(438)897-3098', '1167 rue berrie , montreal, quebec', '2021-10-06', 'montral', 98871, 18, 'OUI', 'OUI', 'hom', ''),
('08:08:00', '2021-10-26', 'hh', 'huh', '(438)897-3098', '1167 rue berrie , montreal, quebec', '2021-10-06', 'montral', 98871, 18, 'OUI', 'OUI', 'hom', ''),
('10:15:00', '2021-12-22', 'el', 'mi', '(438)897-3098', '1167 rue berrie , montreal, quebec', '2011-08-17', 'india', 77554, 18, 'OUI', '', 'hom', 'male au nv du poitrine'),
('10:15:00', '2021-12-22', 'el', 'mi', '(438)897-3098', '1167 rue berrie , montreal, quebec', '2011-08-17', 'india', 77554, 18, 'OUI', '', 'hom', 'male au nv du poitrine');

-- --------------------------------------------------------

--
-- Structure de la table `infermiers`
--

CREATE TABLE `infermiers` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `infermiers`
--

INSERT INTO `infermiers` (`id`, `username`, `password`) VALUES
(1, 'hadil', 'dadda'),
(3, 'oussama', 'ouqail'),
(4, 'younes', 'abou'),
(5, 'hiba', 'elmers'),
(6, 'delwende', 'donald');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `infermiers`
--
ALTER TABLE `infermiers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `infermiers`
--
ALTER TABLE `infermiers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
