<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link href="styleModification.css" rel="stylesheet" type="text/css">
</head>
<style>
#bob{
	
}
.auto-style1 {
	margin-top: 0px;
}
</style>
<body> 
<form   method="post" >

            <table align="center">
             <tr>  
                <td style="height: 123px"> Entrez nom du patient <input type="text"name="nom" required="required"> </td>                         
                <tr> <td style="height: 125px"> Entrez son prenom    <input type="text" name="pnom" required="required"> </td><br></tr>
               
                <tr> <td>  <button type="submit">Supprimer</button>
                 <a href="profileINF.php"><button type="button" >Annuler</button></a></td><br>
            </tr>
                 
 </table>           
 </form>

       <?php 
// Definition des infos de connection
$user = 'root';   // le nom de l'utilisateur
$pass = '';       // le mot de passe 
$host = 'localhost';  // le serveur de base de données
$bdd = 'hopital';  // le nom de la base de données 

// 1eme  etape 
// connection au serveur de la base de donnees
$link = mysqli_connect($host, $user, $pass, $bdd) or die("Erreur de connexion au serveur");

// 3eme etape  : 
// Selectionner la BDD
mysqli_select_db($link, $bdd) or die("Erreur de connexion a la BDD");


$delete = "DELETE FROM ajoute_patient  WHERE nom='$_POST[nom]' and prenom='$_POST[pnom]'";


$rep = mysqli_query($link,$delete) or die("Erreur de Supprimer les donnèes");

// Deconnexion de la BDD
mysqli_close($link);
?>

</body>
</html>