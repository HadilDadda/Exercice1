<html>
<head>

</head>
<body>
    <form method="POST" action="exemple.php">
    <p>LOGIN
        <input type="text" name="login" placeholder="le login" />
    </p>
   
    <p>
      Password
        <input type="password" name="mdp" placeholder="password" />

    </p>
    <input type="submit"  name="valider" value ="ok">
    
      <input  type="submit" name="register" value="Registre" >
</form>
</body>
</html>

<?php
 $servername="localhost";
 $username="root";
 $dbname="users";
 $password="";
  $con =new mysqli($servername,$username,$password,$dbname);
  if($con->connect_error)
  {
     die("connexion failed :".$con->connect_error);
  }
  
 


  
if(isset($_POST['login']) && isset($_POST['mdp']) && isset($_POST['valider']))
{
   $requete=mysqli_query($con,"SELECT * FROM user where login='".$_POST['login']."'and password='".$_POST['mdp']."';    ");
   

//$requete=mysqli_query($con,$sql);
$nombre=mysqli_num_rows($requete);
//le nombre de ligne retournees par la requette
echo $nombre;
if($nombre>0){
  $row=mysqli_fetch_array($requete);//pour lire la requette 
  echo "<br>";
  echo $row[1];//pour afficher le login row[1],pour password le row[2] ,et pour id row[0].
}


}
if(isset($_POST["register"])&& isset($_POST["login"])&& isset($_POST["mdp"])){//insert une valeur dans la table //["registre] le nom quand a fait dna s html
  $login=$_POST["login"];
  $mdp=$_POST["mdp"];
  $sql_i="INSERT INTO user(login,password)VALUES('".$login."','".$mdp."')";//(login,password) dans la base de donne 
 // $sql_b="INSERT INTO user(login,password)VALUES('".$login."','".$mdp.")";
  //echo $sql_i;
  //echo "<br>";//revenir a la ligne 
 // echo $sql_b;

 if (mysqli_query($con,$sql_i)){
   echo"insertion reussie";
 }
 else{
   echo"Erreur :".$sql_i."<br>".mysqli_error($con);

 }
}

?>