<html>
    <head>
    <link href="styleajoute.css" rel="stylesheet" type="text/css">
        
</head>
<body>
<form method="POST" action="ajoute.php">
    <br/>
    <br/>
   
<table align="left" broder="0" width="400px"   height="200px bgcolor="#99CCFF">
    <tr>
        <td width="300px">
          L'Heure de consultation : 
        </td>
        <td>
        <input type="time" name="txttime" style="width:200px"/>
        </td>
    </tr>
    <tr>
        <td width="300px">
            La Date du consultation :
        </td> 
        <td>
            <input type="date" name="dateConsulta" style="width:200px" />
        </td>


    </tr>

</table>
<center>
<table broder="0" width="500px"  height="490px" bgcolor="#99CCFF">
    <br/>
    <br/><br/><br/><br/>
    <thead bgcolor="red" >
        <td colspan="2" align="center">
        FORMULAIRE DU NOTRE PATIENT 
        </td>

</thead>
<tr>
    <td width="200px">
        NOM DE FAMILLE :
    </td>
    <TD>
        <input type="text" name ="txtnom" style="width:200px" />

    </TD>
</tr>
<tr>
    <td width="100px">
        PRENOM :
    </td>
    <td>
        <input type="text" name ="txtprenom" style="width:200px" />
    </td>
</tr>
<tr>
    <td>
        Sexe: 
    </td>
    <td>
         <input type="radio" name="radsex" value="femme"  />Femme<br />
        <input type="radio" name="radsex" value="homme"  />Homme
    </td>

</tr>

<TR>
    <td width="200px" >
        Numero De Telephone :
    </td>
    <td>
        <input type="tel"  name="txtnum" placeholder="(999)999-9999" required="required" patten="\([0-9]{3}\)[0-9]{3}-[0-9]{4} style="width:200px"/>
    </td>
</TR>

<tr>
    <td width="200px">
        ADRESSE :
    </td>
    <TD>
        <input type="text "  name="txtadress" placeholder=" Rue , Ville , Province , Code Postal" style="width:200px"/>
    </TD>
</tr>
<tr>
    <td width="200px">
        Date de Naissance : 
    </td>
    <td>
        <input type="date" name="dateNaissance" style="width:200px" />
    </td>
    <tr>
        <td>
            Lieu de Naissance :
        </td>
        <td>
            <input type="text" name="txtLieux"  style="width:200px"/>
        </td>
    </tr>

</tr>
<tr>
    <td >
        Numero D'assurance maladie :
        <br/>
    </td>
    
    <td>
        <input type="text" name="txtAssur"  style="width:100px"/>
        date d'expiration: 
        <br/>
    </td>
    <td>
        <input type="text" name="txtExp"  placeholder="    /    "  style="width:50px"/>
    </td>
    

</tr>
<tr>
    <td>
        Avez vous la fievre ?
    </td>
    <td>
        <input type="radio" name="radfievre" value="OUI"  />OUI<br />
        <input type="radio" name="radfievre" value="NON" checked="checked" />NON
    </td>
</tr>
<tr>
    <td>
        Avez vous Allergie?
    </td>
    <td>
        <input type="radio" name="radAL" value="OUI"  />OUI<br />
        
        <input type="radio" name="radeAl" value="NON" checked="checked"/>NON
    </td>
</tr>
 <tr>
     <td>
         La raison que vous êtes ici?
     </td>
     <td>
     <input type="text" name ="txtraison" style="width:250px" height="100px"  />
    </td>


 </tr>

<tr>

    <td align="center" colspan="2">
   
    
    <input  type="submit" name="register" value="Registre" >
</tr>
    
</tr>
</table>
</center>
   
    </form>
</body>
</html>

<?php

$servername="localhost";
 $username="root";
 $dbname="hopital";
 $password="";
 $con=new mysqli($servername,$username,$password,$dbname);
 if ($con->connect_error)
 {
     die ("connexion failed:".$con->connect_error);
 }
 
if(isset($_POST["register"]))
{
    $txtime=$_POST["txttime"];
    $consultation=$_POST["dateConsulta"];
    $nom=$_POST["txtnom"];
    $prenom=$_POST["txtprenom"];
    $tel=$_POST["txtnum"];
    $adress=$_POST["txtadress"];
    $naissance=$_POST["dateNaissance"];
    $lieux=$_POST["txtLieux"];
    $numeroAss=$_POST["txtAssur"];
    $exp=$_POST["txtExp"];
    $fievre=$_POST["radfievre"];
    $allergie=$_POST["radAL"];
    $sexe=$_POST["radsex"];
    $raison=$_POST["txtraison"];
    //echo $fievre ;
    $sql_i="INSERT INTO ajoute_patient( heure,data,nom,prenom,numero,adress,date,lieu,numeroAss,expiration,fievre,allergie,sexe,raison)VALUES('".$txtime."','".$consultation."','". $nom."','".$prenom."','".$tel."','".  $adress."','".$naissance."','".$lieux."','".$numeroAss."','". $exp."','".$fievre."','".$allergie."','".$sexe."','".$raison."')";//(login,password) dans la base de donne
    if (mysqli_query($con,$sql_i)){
        echo"insertion reussie";
      }
      else{
        echo"Erreur :".$sql_i."<br>".mysqli_error($con);
     
      }

}





?>







