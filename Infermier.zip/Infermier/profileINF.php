
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="styleModification.css" rel="stylesheet" type="text/css">
    
</head>
<body>
  <center>
    <?php

session_start();
echo"Bonjour ";
echo $_SESSION['user'];

?>
        </center>
    <table border="0" align="left">
        <tr>
            <td>
                <a href="gmd.html">Modifier Login</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="ajoute.php">Ajout Patient</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="modifierPatient.php">Modifier infos Patients</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="index.php">Deconnexion</a>
            </td>
        </tr>
        
    
        
    </table>
        

    
</body>
</html>