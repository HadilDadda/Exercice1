<?php

session_start();
echo"Bonjour ";
echo $_SESSION['user'];

?>