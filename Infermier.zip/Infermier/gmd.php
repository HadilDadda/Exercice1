<?php 
// Definition des infos de connection
$user = 'root';   // le nom de l'utilisateur
$pass = '';       // le mot de passe 
$host = 'localhost';  // le serveur de base de données
$bdd = 'hopital';  // le nom de la base de données 

// 1eme  etape 
// connection au serveur de la base de donnees
$link = mysqli_connect($host, $user, $pass, $bdd) or die("Erreur de connexion au serveur");

// 3eme etape  : 
// Selectionner la BDD
mysqli_select_db($link, $bdd) or die("Erreur de connexion a la BDD");

//Exécuter le UPDATE dans la table
$update = "UPDATE infermiers  SET username='$_POST[userN]',password='$_POST[mot2pasN]' WHERE username='$_POST[user]' and password='$_POST[mot2pas]' ";


$rep = mysqli_query($link,$update) or die("Erreur de modification des donnèes");

// Deconnexion de la BDD
mysqli_close($link);
?>