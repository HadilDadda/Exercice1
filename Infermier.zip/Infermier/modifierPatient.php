<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="styleajoute.css" rel="stylesheet" type="text/css">
</head>
<body>
<form method="POST" >
    <br/>
    <br/>
   
<table align="left" broder="0" width="400px"   height="200px bgcolor="#99CCFF">
    <tr>
        <td width="300px">
          L'Heure de consultation : 
        </td>
        <td>
        <input type="time" name="txttime" style="width:200px"  />
        </td>
    </tr>
    <tr>
        <td width="300px">
            La Date du consultation :
        </td> 
        <td>
            <input type="date" name="dateConsulta" style="width:200px" />
        </td>


    </tr>

</table>
<center>
<table broder="0" width="500px"  height="490px" bgcolor="#99CCFF">
    <br/>
    <br/><br/><br/><br/>
    <thead bgcolor="red" >
        <td colspan="2" align="center">
       MISE À JOUR DU FORMULAIRE DU NOTRE PATIENT 
        </td>

</thead>
<tr>
    <td width="200px">
        NOM DE FAMILLE :
    </td>
    <TD>
        <input type="text" name ="txtnom" style="width:200px"  />

    </TD>
</tr>
<tr>
    <td width="100px">
        PRENOM :
    </td>
    <td>
        <input type="text" name ="txtprenom"   style="width:200px" />
    </td>
</tr>
<tr>
    <td>
        Sexe: 
    </td>
    <td>
         <input type="radio" name="radsex" value="femme"  />Femme<br />
        <input type="radio" name="radsex" value="homme"  />Homme
    </td>

</tr>

<TR>
    <td width="200px" >
        Numero De Telephone :
    </td>
    <td>
        <input type="tel"  name="txtnum" placeholder="(999)999-9999"   required="required" patten="\([0-9]{3}\)[0-9]{3}-[0-9]{4} style="width:200px"/>
    </td>
</TR>

<tr>
    <td width="200px">
        ADRESSE :
    </td>
    <TD>
        <input type="text "  name="txtadress" placeholder=" Rue , Ville , Province , Code Postal" style="width:200px"/>
    </TD>
</tr>
<tr>
    <td width="200px">
        Date de Naissance : 
    </td>
    <td>
        <input type="date" name="dateNaissance" style="width:200px" />
    </td>
    <tr>
        <td>
            Lieu de Naissance :
        </td>
        <td>
            <input type="text" name="txtLieu"  style="width:200px"/>
        </td>
    </tr>

</tr>
<tr>
    <td >
        Numero D'assurance maladie :
        <br/>
    </td>
    
    <td>
        <input type="text" name="txtAssur"  style="width:100px"/>
        date d'expiration: 
        <br/>
    </td>
    <td>
        <input type="text" name="txtExp"  placeholder="    /    "  style="width:50px"/>
    </td>
    

</tr>
<tr>
    <td>
        Avez vous la fievre ?
    </td>
    <td>
        <input type="radio" name="radfievre" value="OUI"  />OUI<br />
        <input type="radio" name="radfievre" value="NON" checked="checked" />NON
    </td>
</tr>
<tr>
    <td>
        Avez vous Allergie?
    </td>
    <td>
        <input type="radio" name="radAL" value="OUI"  />OUI<br />
        
        <input type="radio" name="radAl" value="NON" checked="checked"/>NON
    </td>
</tr>
 <tr>
     <td>
         La raison que vous êtes ici?
     </td>
     <td>
     <input type="text" name ="txtraison" style="width:250px" height="100px"  />
    </td>


 </tr>

<tr>

    <td align="center" colspan="2">
   
    
    <input  type="submit" name="Mod" value="Modifier" >
</tr>
    
</tr>
</table>
</center>
   
    </form>
</body>
</html>
<?php
if (isset($_POST['Mod']))
{
session_start();
$user = 'root';   
$pass = '';      
$host = 'localhost'; 
$bdd = 'hopital';  


$link = mysqli_connect($host, $user, $pass, $bdd) or die("Erreur de connexion au serveur");


mysqli_select_db($link, $bdd) or die("Erreur de connexion a la BDD");


$update = "UPDATE ajoute_patient SET heure='$_POST[txttime]',data='$_POST[dateConsulta]',numero='$_POST[txtnum]',adress='$_POST[txtadress]',date='$_POST[dateNaissance]',lieu='$_POST[txtLieu]',numeroAss='$_POST[txtAssur]',expiration='$_POST[txtExp]',fievre='$_POST[radfievre]',Allergie='$_POST[radAl]',raison='$_POST[txtraison]' WHERE nom='$_POST[txtnom]' and prenom='$_POST[txtprenom]'";

$rep = mysqli_query($link,$update) or die("Erreur de modification des donnèes");


mysqli_close($link);
}

?>
